// ============================================================================
// ENHANCED HISTORY COMMAND - FIXED VERSION
// Works with db module exports (not raw database)
// ============================================================================

const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

// Configuration
const TRANSCRIPT_BASE_URL = process.env.TRANSCRIPT_URL || 'http://localhost:3001';
const TICKETS_PER_PAGE = 25;

/**
 * Handle /history command - Shows user history with ticket dropdown
 */
async function handleHistoryCommand(interaction, db) {
    const targetUser = interaction.options.getUser('user');
    
    // Permission check for viewing others
    const isStaff = interaction.member.permissions.has('Administrator') || 
                    interaction.member.permissions.has('ManageThreads') ||
                    interaction.member.roles.cache.some(r => 
                        ['azam', 'bartender', 'assistant', 'staff', 'mod'].some(name => 
                            r.name.toLowerCase().includes(name)
                        )
                    );
    
    if (targetUser && targetUser.id !== interaction.user.id && !isStaff) {
        return interaction.editReply({ 
            content: '❌ You can only view your own history.'
        });
    }
    
    const userId = targetUser?.id || interaction.user.id;
    const username = targetUser?.username || interaction.user.username;
    const userAvatar = targetUser?.displayAvatarURL() || interaction.user.displayAvatarURL();
    
    // Get ALL tickets for user
    const tickets = db.getUserTickets(userId, 100);
    const totalTickets = tickets.length;
    const openTickets = tickets.filter(t => t.status === 'open').length;
    
    if (totalTickets === 0) {
        return interaction.editReply({ 
            content: `📋 No ticket history found for **${username}**`
        });
    }
    
    // Get cooldown status
    const ticketCooldown = db.getUserCooldown(userId, interaction.guild.id, 'ticket');
    const hdCooldown = db.getUserCooldown(userId, interaction.guild.id, 'high_demand');
    
    // Check blacklist
    const isBlacklisted = false; // Replace with actual check if needed
    
    // Build main embed
    const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle(`${username}'s History`)
        .setThumbnail(userAvatar)
        .addFields(
            { name: 'Total Tickets', value: `${totalTickets}`, inline: true },
            { name: 'Open Tickets', value: `${openTickets}`, inline: true },
            { name: 'Blacklisted', value: isBlacklisted ? '✅' : '❌', inline: true }
        );
    
    // Add cooldown info if active
    if (ticketCooldown || hdCooldown) {
        let cooldownText = '';
        if (ticketCooldown) {
            const expires = new Date(ticketCooldown.expires_at);
            cooldownText += `⏱️ Ticket: <t:${Math.floor(expires.getTime()/1000)}:R>\n`;
        }
        if (hdCooldown) {
            const expires = new Date(hdCooldown.expires_at);
            cooldownText += `🔥 High Demand: <t:${Math.floor(expires.getTime()/1000)}:R>`;
        }
        embed.addFields({ name: '🚦 Active Cooldowns', value: cooldownText, inline: false });
    }
    
    // Guild footer
    const guildEmoji = interaction.guild.name.toLowerCase().includes('free') ? '🆓' : '💰';
    embed.setFooter({ text: `${guildEmoji} ${interaction.guild.name}` });
    
    // Build dropdown menu with tickets (first page)
    const ticketsForDropdown = tickets.slice(0, TICKETS_PER_PAGE);
    const options = ticketsForDropdown.map(t => {
        const game = db.getGame(t.game_id);
        const gameName = game?.game_name || t.game_id || 'Unknown Game';
        const date = new Date(t.created_at);
        const dateStr = `${date.getDate().toString().padStart(2,'0')}/${(date.getMonth()+1).toString().padStart(2,'0')}/${date.getFullYear()}`;
        const statusEmoji = t.status === 'closed' ? '🔴' : '🟢';
        
        // Truncate for dropdown limits
        const displayName = gameName.length > 40 ? gameName.substring(0, 37) + '...' : gameName;
        
        return {
            label: t.ticket_id.substring(0, 25),
            description: `${displayName} - ${dateStr}`,
            value: t.ticket_id,
            emoji: statusEmoji
        };
    });
    
    const selectMenu = new StringSelectMenuBuilder()
        .setCustomId(`history_select_${userId}_0`)
        .setPlaceholder('Select a Ticket')
        .addOptions(options);
    
    const row = new ActionRowBuilder().addComponents(selectMenu);
    
    // Add pagination if needed
    const components = [row];
    if (totalTickets > TICKETS_PER_PAGE) {
        const pageRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`history_page_${userId}_1`)
                .setLabel('Next Page')
                .setEmoji('➡️')
                .setStyle(ButtonStyle.Secondary)
        );
        components.push(pageRow);
    }
    
    await interaction.editReply({ 
        embeds: [embed], 
        components
    });
}

/**
 * Handle ticket selection from dropdown
 */
async function handleHistorySelect(interaction, db) {
    const ticketId = interaction.values[0];
    const ticket = db.getTicket(ticketId);
    
    if (!ticket) {
        return interaction.update({ 
            content: '❌ Ticket not found in database.', 
            embeds: [],
            components: [] 
        });
    }
    
    const game = db.getGame(ticket.game_id);
    const gameName = game?.game_name || ticket.game_id || 'Unknown Game';
    
    // Format dates
    const createdAt = new Date(ticket.created_at);
    const createdStr = `${createdAt.getDate()} ${createdAt.toLocaleString('en-GB', { month: 'long' })} ${createdAt.getFullYear()} ${createdAt.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`;
    
    let closedStr = 'N/A';
    if (ticket.closed_at) {
        const closedAt = new Date(ticket.closed_at);
        closedStr = `${closedAt.getDate()} ${closedAt.toLocaleString('en-GB', { month: 'long' })} ${closedAt.getFullYear()} ${closedAt.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`;
    }
    
    // Determine panel type
    const panelType = game?.demand_type === 'high' ? '🔥 high' : game?.free_panel ? '🆓 free' : '💰 paid';
    
    // Build detail embed
    const embed = new EmbedBuilder()
        .setColor(ticket.status === 'closed' ? 0x808080 : 0x5865F2)
        .setTitle(ticketId)
        .addFields(
            { name: '📋 Information', value: '\u200b', inline: false },
            { name: 'Panel', value: panelType, inline: true },
            { name: 'Status', value: ticket.status === 'closed' ? '🔒 Closed' : '🟢 Open', inline: true }
        );
    
    // Add created info
    embed.addFields(
        { name: 'Created', value: `• At: ${createdStr}\n• By: <@${ticket.user_id}>`, inline: false }
    );
    
    // Add closed info if closed
    if (ticket.status === 'closed') {
        embed.addFields(
            { name: 'Closed', value: `• At: ${closedStr}\n• Reason: ${ticket.close_reason || 'N/A'}`, inline: false }
        );
    }
    
    // Add game info
    embed.addFields(
        { name: '🎮 Game', value: gameName, inline: false }
    );
    
    // Add refill info if applicable
    if (ticket.is_refill) {
        embed.addFields(
            { name: '🔄 Refill', value: `Steam ID: ${ticket.steam_id || 'Not provided'}`, inline: false }
        );
    }
    
    // Guild footer
    embed.setFooter({ text: `🍺 THE PUB` });
    
    // Check for transcript using db.getTranscript (the proper exported function)
    let hasTranscript = false;
    let transcriptId = ticketId;
    
    try {
        const transcript = db.getTranscript(ticketId);
        if (transcript && transcript.messages_json) {
            hasTranscript = true;
            transcriptId = transcript.ticket_id || ticketId;
        }
    } catch (e) {
        console.log(`[History] Transcript lookup error: ${e.message}`);
    }
    
    // Build buttons
    const buttons = [];
    
    // Transcript button
    if (hasTranscript && transcriptId) {
        const transcriptUrl = `${TRANSCRIPT_BASE_URL}/${encodeURIComponent(transcriptId)}`;
        buttons.push(
            new ButtonBuilder()
                .setLabel('Transcript')
                .setEmoji('📜')
                .setStyle(ButtonStyle.Link)
                .setURL(transcriptUrl)
        );
    } else {
        // Show info that no transcript exists in embed
        embed.addFields({
            name: '📜 Transcript',
            value: 'No transcript available for this ticket',
            inline: false
        });
    }
    
    const components = buttons.length > 0 ? [new ActionRowBuilder().addComponents(buttons)] : [];
    
    // Update the message
    await interaction.update({ 
        embeds: [embed], 
        components 
    });
}

/**
 * Handle pagination
 */
async function handleHistoryPage(interaction, db, targetUserId, page) {
    const tickets = db.getUserTickets(targetUserId, 100);
    const start = page * TICKETS_PER_PAGE;
    const ticketsForDropdown = tickets.slice(start, start + TICKETS_PER_PAGE);
    
    if (ticketsForDropdown.length === 0) {
        return interaction.reply({ content: '❌ No more tickets.', ephemeral: true });
    }
    
    const options = ticketsForDropdown.map(t => {
        const game = db.getGame(t.game_id);
        const gameName = game?.game_name || t.game_id || 'Unknown';
        const date = new Date(t.created_at);
        const dateStr = `${date.getDate().toString().padStart(2,'0')}/${(date.getMonth()+1).toString().padStart(2,'0')}/${date.getFullYear()}`;
        const statusEmoji = t.status === 'closed' ? '🔴' : '🟢';
        
        return {
            label: t.ticket_id.substring(0, 25),
            description: `${gameName.substring(0, 40)} - ${dateStr}`,
            value: t.ticket_id,
            emoji: statusEmoji
        };
    });
    
    const selectMenu = new StringSelectMenuBuilder()
        .setCustomId(`history_select_${targetUserId}_${page}`)
        .setPlaceholder('Select a Ticket')
        .addOptions(options);
    
    const row = new ActionRowBuilder().addComponents(selectMenu);
    const components = [row];
    
    // Pagination buttons
    const pageButtons = [];
    if (page > 0) {
        pageButtons.push(
            new ButtonBuilder()
                .setCustomId(`history_page_${targetUserId}_${page - 1}`)
                .setLabel('Previous')
                .setEmoji('⬅️')
                .setStyle(ButtonStyle.Secondary)
        );
    }
    if (start + TICKETS_PER_PAGE < tickets.length) {
        pageButtons.push(
            new ButtonBuilder()
                .setCustomId(`history_page_${targetUserId}_${page + 1}`)
                .setLabel('Next Page')
                .setEmoji('➡️')
                .setStyle(ButtonStyle.Secondary)
        );
    }
    
    if (pageButtons.length > 0) {
        components.push(new ActionRowBuilder().addComponents(pageButtons));
    }
    
    await interaction.update({ components });
}

module.exports = {
    handleHistoryCommand,
    handleHistorySelect,
    handleHistoryPage,
    TRANSCRIPT_BASE_URL
};
